﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

/*
 * Jandre van der Merwe
 * 2019/02/11
 * application form to play the game
*/
namespace BlackJack //form name
{

    public partial class Form1 : Form
    {
        public static string passingBackLabel;
        public void Form1_Load(object sender, EventArgs e)
        {

            totalChips.Text = BlackJack_start.passingLabel;
            
        }
        
        int playerscore = 0; //declare varaibles for dealer and player score
        int dealerscore = 0;
        
        int betAmount = 0;
        int WenChips = 0;

        string[] player = new string[7]; //creates a new string for the dealer's cards and the player's cards
        string[] dealer = new string[7];

        string[] chosencards = new string[52]; //creates a new string for the cards in the deck
        int i = 0;

        int W = 0; //sets win variable 0
        int L = 0; //sets lose variable 0
        int D = 0; //sets draw variable 0

        SortedList sl = new SortedList(); //creates a sorted list to add all the cards

        public void score(string playerCard, string dealerCard) //counts the card values if user has an ace
        {
            if (playerCard != null)
            {             
                
                playerscore += Convert.ToInt32(sl[playerCard]);
                if (Convert.ToInt32(sl[playerCard]) == 11) //checks the card value
                {
                    acesPlayer++; //ads an ace to check if ace value needs to be 11 or one for player
                }
            }            
            else
            {               
                dealerscore += Convert.ToInt32(sl[dealerCard]);
                if (Convert.ToInt32(sl[dealerCard]) == 11) //checks the card value
                {
                    acesDealer++; //ads an ace to check if ace value needs to be 11 or one for dealer
                }
                
            }            
            scoreDealer.Text = dealerscore.ToString(); //counts the dealer score from text to integer
            scorePlayer.Text = playerscore.ToString(); //counts the player score from text to integer
        }                
        
        public Form1()
        {
            InitializeComponent(); //inputs the cards into the string that was created for the deck
           
            sl.Add("Clubs-Ace", "11");
            sl.Add("Clubs-Two", "2");
            sl.Add("Clubs-Three", "3");
            sl.Add("Clubs-Four", "4");
            sl.Add("Clubs-Five", "5");
            sl.Add("Clubs-Six", "6");
            sl.Add("Clubs-Seven", "7");
            sl.Add("Clubs-Eight", "8");
            sl.Add("Clubs-Nine", "9");
            sl.Add("Clubs-Ten", "10");
            sl.Add("Clubs-Jack", "10");
            sl.Add("Clubs-Queen", "10");
            sl.Add("Clubs-King", "10");
            sl.Add("Diamonds-Ace", "11");
            sl.Add("Diamonds-Two", "2");
            sl.Add("Diamonds-Three", "3");
            sl.Add("Diamonds-Four", "4");
            sl.Add("Diamonds-Five", "5");
            sl.Add("Diamonds-Six", "6");
            sl.Add("Diamonds-Seven", "7");
            sl.Add("Diamonds-Eight", "8");
            sl.Add("Diamonds-Nine", "9");
            sl.Add("Diamonds-Ten", "10");
            sl.Add("Diamonds-Jack", "10");
            sl.Add("Diamonds-Queen", "10");
            sl.Add("Diamonds-King", "10");
            sl.Add("Hearts-Ace", "11");
            sl.Add("Hearts-Two", "2");
            sl.Add("Hearts-Three", "3");
            sl.Add("Hearts-Four", "4");
            sl.Add("Hearts-Five", "5");
            sl.Add("Hearts-Six", "6");
            sl.Add("Hearts-Seven", "7");
            sl.Add("Hearts-Eight", "8");
            sl.Add("Hearts-Nine", "9");
            sl.Add("Hearts-Ten", "10");
            sl.Add("Hearts-Jack", "10");
            sl.Add("Hearts-Queen", "10");
            sl.Add("Hearts-King", "10");
            sl.Add("Spades-Ace", "11");
            sl.Add("Spades-Two", "2");
            sl.Add("Spades-Three", "3");
            sl.Add("Spades-Four", "4");
            sl.Add("Spades-Five", "5");
            sl.Add("Spades-Six", "6");
            sl.Add("Spades-Seven", "7");
            sl.Add("Spades-Eight", "8");
            sl.Add("Spades-Nine", "9");
            sl.Add("Spades-Ten", "10");
            sl.Add("Spades-Jack", "10");
            sl.Add("Spades-Queen", "10");
            sl.Add("Spades-King", "10");
        }

        int acesPlayer = 0; //sets the aces that a player has to zero
        int acesDealer = 0; //sets the aces that the dealer has to zero

        int dealplayer = 0; //sets the deal players case to zero

        private void button1_Click(object sender, EventArgs e) //hit button
        {
           
            {
                string kaart = ""; //creates a string for the cards that is draw
                switch (dealplayer) //creates switch case for the dealer
                {
                    case 0:
                        kaart = sl.GetKey(GetRandom()).ToString(); //gets random card
                        player3.Image = Image.FromFile("../../Resources/" + kaart + ".png");//displays random card in imagebox 3
                        player3.Visible = true; //make the card visible
                        player3.BringToFront(); //bring card to front
                        score(kaart, null); //count value of card to the score
                        
                        if ( playerscore > 21) //checks if score is greater than 21
                        {
                            if (acesPlayer > 0) //checks if user hasd an ace
                            {
                                playerscore -= 10; //substract 10 from user value to change ace value so that user does not bust
                                acesPlayer--; //minus one from total aces that user has
                                scorePlayer.Text = playerscore.ToString(); //sets player score
                            }
                            else //if first condition is not met
                            {
                                hit.Visible = false; //if user score is greater than 21 user are not allowed to draw again
                                playerbust.Visible = true; //user bust is displayed
                                playerbust.BringToFront(); //shown on top of cards
                                dealerdraw(); //dealer draws for himself
                            }                            
                        }
                        break; //end of first case

                    case 1:
                        kaart = sl.GetKey(GetRandom()).ToString(); //gets random card
                        player4.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //displays random card in imagebox 4
                        player4.Visible = true; //make the card visible
                        player4.BringToFront(); //bring card to front
                        score(kaart, null); //count value of card to the score

                        if (playerscore > 21) //checks if score is greater than 21
                        {
                            if (acesPlayer > 0) //checks if user hasd an ace
                            {
                                playerscore -= 10; //substract 10 from user value to change ace value so that user does not bust
                                acesPlayer--; //minus one from total aces that user has
                                scorePlayer.Text = playerscore.ToString(); //sets player score
                            }
                            else //if first condition is not met
                            {
                                hit.Visible = false; //if user score is greater than 21 user are not allowed to draw again
                                playerbust.Visible = true; //user bust is displayed
                                playerbust.BringToFront(); //shown on top of cards
                                dealerdraw(); //dealer draws for himself
                            }
                        }
                        break; //end of second case
                    
                    case 2:
                        kaart = sl.GetKey(GetRandom()).ToString(); //gets random card
                        player5.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //displays random card in imagebox 5
                        player5.Visible = true; //make the card visible
                        player5.BringToFront(); //bring card to front
                        score(kaart, null); //count value of card to the score 
                        
                        if (playerscore > 21) //checks if score is greater than 21
                        {
                            if (acesPlayer > 0) //checks if user hasd an ace
                            {
                                playerscore -= 10; //substract 10 from user value to change ace value so that user does not bust
                                acesPlayer--; //minus one from total aces that user has
                                scorePlayer.Text = playerscore.ToString(); //sets player score
                            }
                            else //if first condition is not met
                            {
                                hit.Visible = false; //if user score is greater than 21 user are not allowed to draw again
                                playerbust.Visible = true; //user bust is displayed
                                playerbust.BringToFront(); //shown on top of cards
                                dealerdraw(); //dealer draws for himself
                            }
                        }
                        break; //end of third case

                    case 3:
                        kaart = sl.GetKey(GetRandom()).ToString(); //gets random card
                        player6.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //displays random card in imagebox 6
                        player6.Visible = true; //make the card visible
                        player6.BringToFront(); //bring card to front
                        score(kaart, null); //count value of card to the score     
                        
                        if (playerscore > 21) //checks if score is greater than 21
                        {
                            if (acesPlayer > 0) //checks if user hasd an ace
                            {
                                playerscore -= 10; //substract 10 from user value to change ace value so that user does not bust
                                acesPlayer--; //minus one from total aces that user has
                                scorePlayer.Text = playerscore.ToString(); //sets player score
                            }
                            else //if first condition is not met
                            {
                                hit.Visible = false; //if user score is greater than 21 user are not allowed to draw again
                                playerbust.Visible = true; //user bust is displayed
                                playerbust.BringToFront(); //shown on top of cards
                                dealerdraw(); //dealer draws for himself
                            }
                        }
                        break; //end of fourth case

                    case 4:
                        kaart = sl.GetKey(GetRandom()).ToString(); //gets random card
                        player7.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //displays random card in imagebox 7
                        player7.Visible = true; //make the card visible
                        player7.BringToFront(); //bring card to front
                        score(kaart, null); //count value of card to the score      
                        
                        if (playerscore > 21) //checks if score is greater than 21
                        {
                            if (acesPlayer > 0) //checks if user hasd an ace
                            {
                                playerscore -= 10; //substract 10 from user value to change ace value so that user does not bust
                                acesPlayer--; //minus one from total aces that user has
                                scorePlayer.Text = playerscore.ToString(); //sets player score
                            }
                            else //if first condition is not met
                            {
                                hit.Visible = false; //if user score is greater than 21 user are not allowed to draw again
                                playerbust.Visible = true; //user bust is displayed
                                playerbust.BringToFront(); //shown on top of cards
                                dealerdraw(); //dealer draws for himself
                            }
                        }
                        break; //end of fifth case

                }

            }
            dealplayer++; //changes the case to the next everytime player hits the button

        }

        private int GetRandom() //gets random card
        {
            int res = Random(); //sets random number as int

            while (chosencards.Contains(res.ToString())) //if card is already used it must go to a new string
            {
                res = Random(); //check if unique random card
            }

            chosencards[i] = res.ToString(); //gets cards from string
            i++; //deal new card if card is used

            return res; //returns the card
            
        }

        public int Random() //gets random number to link with cards
        {                      
            Random random = new Random(); //new random card

            int randomCard = random.Next(0, 52); //number of cards wich can be chosen from
            return randomCard; //returns random number
        }
     
        private void button1_Click_1(object sender, EventArgs e) //playt again button
        {
            betAmount = 0;
            BetAmountLbl.Text = betAmount.ToString();

            pictureBoxBets.Visible = false;

            chip25.Visible = true;
            chip50.Visible = true;
            chip100.Visible = true;
            chip500.Visible = true;
            chip1000.Visible = true;
            ClearBet.Visible = true;

            i = 0; //sets all varaibles back to zero to restart the game except scoreboard
            dealplayer = 0;
            dealdealer = 0;

            dealerscore = 0;
            playerscore = 0;

            acesDealer = 0;
            acesPlayer = 0;

            DEAL.Visible = true; //enable player to deal new deck
            button1.Visible = false; //hides play again button
            stand.Visible = false; //hides all buttons that is not in used
            hit.Visible = false;
            playerbust.Visible = false;
            dealerbust.Visible = false;

            player1.Image = null; //sets all the players imageboxes to clear
            player2.Image = null;
            player3.Image = null;
            player4.Image = null;
            player5.Image = null;
            player6.Image = null;
            player7.Image = null;

            dealer1.Image = null; //sets all the dealer imageboxes to clear
            dealer2.Image = null;
            dealer3.Image = null;
            dealer4.Image = null;
            dealer5.Image = null;
            dealer6.Image = null;
            dealer7.Image = null;

            for (int i = 0; i < chosencards.Length; i++)
            {
                chosencards[i] = ""; //adds cards to deck
            }            
        }

        int dealdealer = 0;

        private void stand_Click(object sender, EventArgs e)
        {
            dealerdraw(); //deals card for dealer
        }

        public void dealerdraw()
        {            
            hit.Visible = false; //disable buttpns that il not be used
            stand.Visible = false;
            button1.Visible = true;

            string kaart = ""; //gets deck of cards
            kaart = sl.GetKey(GetRandom()).ToString(); //gets random card to deal

            dealer2.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //shows the dealers second card
            dealer2.Visible = true; //make the card visible
            dealer2.BringToFront(); //brings the card to the front

            score(null, kaart); //counts the dealer score

            {
                Scoring(playerscore, dealerscore);
                if (dealerscore > 21) //checks if dealer score is greater than 21
                {
                    stand.Visible = false;
                    dealerbust.Visible = true;
                    dealerbust.BringToFront();
                }
            }

            while (dealerscore < 17) //switch case will be initialized until dealerscore is greater than 16
            {
                switch (dealdealer) //greates switch case for dealer to draw cards

                {

                    case 0:
                        kaart = sl.GetKey(GetRandom()).ToString(); //draws a random card
                        dealer3.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //deals card in 3rd image box
                        dealer3.Visible = true; //makes the card vsible
                        dealer3.BringToFront(); //makes the card displa on top of the other
                        score(null, kaart); //counts the new score

                        if (dealerscore > 21) //checks if dealer score is greater than 21
                        {
                            if (acesDealer > 0) //checks if user has an ace
                            {
                                dealerscore -= 10; //if user has ace and bust then reduce ten from score
                                acesDealer--; //remove one ace from the total of delaer aces
                                scoreDealer.Text = dealerscore.ToString(); //create new score
                            }
                            else //dealer bust
                            {
                                stand.Visible = false;
                                dealerbust.Visible = true;
                                dealerbust.BringToFront();
                            }                           
                        }

                        break;

                    case 1:
                        kaart = sl.GetKey(GetRandom()).ToString(); //draws a random card
                        dealer4.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //show image in 4th box
                        dealer4.Visible = true;
                        dealer4.BringToFront();
                        score(null, kaart);

                        if (dealerscore > 21) //check if greater than 21
                        {
                            if (acesDealer > 0) //check if user has an ace
                            {
                                dealerscore -= 10;
                                acesDealer--;
                                scoreDealer.Text = dealerscore.ToString();
                            }
                            else //dealer bust
                            {
                                stand.Visible = false;
                                dealerbust.Visible = true;
                                dealerbust.BringToFront();
                            }
                        }

                        break;

                    case 2:
                        kaart = sl.GetKey(GetRandom()).ToString(); //draws a random card
                        dealer5.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //show image in  5th box
                        dealer5.Visible = true;
                        dealer5.BringToFront();
                        score(null, kaart);

                        if (dealerscore > 21) //check if greater than 21
                        {
                            if (acesDealer > 0) //check if user has an ace
                            {
                                dealerscore -= 10;
                                acesDealer--;
                                scoreDealer.Text = dealerscore.ToString();
                            }
                            else //dealer bust
                            {
                                stand.Visible = false;
                                dealerbust.Visible = true;
                                dealerbust.BringToFront();
                            }
                        }

                        break;

                    case 3:
                        kaart = sl.GetKey(GetRandom()).ToString(); //draws a random card
                        dealer6.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //show image in 6th box
                        dealer6.Visible = true;
                        dealer6.BringToFront();
                        score(null, kaart);

                        if (dealerscore > 21) //check if greater than 21
                        {
                            if (acesDealer > 0) //check if user has an ace
                            {
                                dealerscore -= 10;
                                acesDealer--;
                                scoreDealer.Text = dealerscore.ToString();
                            }
                            else //dealer bust
                            {
                                stand.Visible = false;
                                dealerbust.Visible = true;
                                dealerbust.BringToFront();
                            }
                        }

                        break;

                    case 4:
                        kaart = sl.GetKey(GetRandom()).ToString(); //draws a random card
                        dealer7.Image = Image.FromFile("../../Resources/" + kaart + ".png"); //show image in 7th box
                        dealer7.Visible = true;
                        dealer7.BringToFront();
                        score(null, kaart);

                        if (dealerscore > 21) //check if greater than 21
                        {
                            if (acesDealer > 0) //check if user has an ace
                            {
                                dealerscore -= 10;
                                acesDealer--;
                                scoreDealer.Text = dealerscore.ToString();
                            }
                            else //dealer bust
                            {
                                stand.Visible = false;
                                dealerbust.Visible = true;
                                dealerbust.BringToFront();
                            }
                        }

                        break;                        
                }
                dealdealer++; //sets the dealer to next case if the score is less thean 17

            }
            Scoring(playerscore, dealerscore); //displays player and dealers score
        }


        private void DEAL_Click(object sender, EventArgs e) //deals two cards for player and two for dealer
        {
            pictureBoxBets.Visible = true;

            if (betAmount < 50)
            {
                MessageBox.Show("Place your bets!", "Minimum bet of 50!", MessageBoxButtons.OK);
            }
            else
            {
                var intVal = Convert.ToInt32(totalChips.Text);
                int teveel = intVal + 1;
                if (betAmount < teveel)
                {
                    //var intVal = Convert.ToInt32(totalChips.Text);
                    intVal -= betAmount;
                    totalChips.Text = intVal.ToString();

                    chip25.Visible = false;
                    chip50.Visible = false;
                    chip100.Visible = false;
                    chip500.Visible = false;
                    chip1000.Visible = false;
                    ClearBet.Visible = false;

                    string card = sl.GetKey(GetRandom()).ToString(); //gets raqndom cards
                    player[0] = card;
                    if (player[0] == card)
                    {

                    }

                    string a = ""; //first card for player
                    string b = ""; //second card for player
                    string c = ""; //first card for dealer

                    a = sl.GetKey(GetRandom()).ToString(); //gets random cards
                    b = sl.GetKey(GetRandom()).ToString();
                    c = sl.GetKey(GetRandom()).ToString();

                    player1.Image = Image.FromFile("../../Resources/" + a + ".png"); //deals first player card
                    player1.Visible = true;
                    score(a, null); //count score

                    player2.Image = Image.FromFile("../../Resources/" + b + ".png"); //deals second player card
                    player2.Visible = true;
                    player2.BringToFront(); //show card on top
                    score(b, null);

                    if (acesPlayer > 0 && playerscore > 21) //check if user has aces
                    {
                        playerscore -= 10;
                        acesPlayer--;
                        scorePlayer.Text = playerscore.ToString();
                    }

                    if (playerscore == 21) //check if player has 21 after two cards
                    {
                        MessageBox.Show("!!BLACKJACK!!", "BlackJack!", MessageBoxButtons.OK); //shows message box showing blackjack
                        hit.Visible = false; //hides the hit button

                        var intVa = Convert.ToInt32(totalChips.Text);
                        WenChips = intVa + (betAmount /2);
                        totalChips.Text = WenChips.ToString();
                    }

                    dealer1.Image = Image.FromFile("../../Resources/" + c + ".png"); //deals card for dealer
                    dealer1.Visible = true;
                    score(null, c);

                    dealer2.Image = Image.FromFile("../../Resources/" + "CardBack.png"); //deals second card with back of card showing
                    dealer2.Visible = true;
                    dealer2.BringToFront(); //show card on top

                    if (acesDealer > 0 && dealerscore > 21) //check if dealer has an ace
                    {
                        dealerscore -= 10;
                        acesDealer--;
                        scoreDealer.Text = dealerscore.ToString();
                    }

                    button1.Visible = true; //show hit button
                    stand.Visible = true; //show stand button


                    if (playerscore < 21) //check if playerscore is less than 21
                    {
                        hit.Visible = true; //hit button visible
                    }

                    DEAL.Visible = false; //deal button must be hidden
                    button1.Visible = false;

                }
                else
                {
                    MessageBox.Show("Sorry you have run out of chips! To get more buy from the main menu by clicking on your chip stash!", "Oops!", MessageBoxButtons.OK);
                }
            }
        }
        public void Scoring(int playerscore, int dealerscore) //scores the dealer and player scores
        {
            //string winGame = "verloor";

            //while (winGame != "Wenner")
            //{ 
                if (dealerscore > 16) //check if dealer score is greater than 16
                {
                    if (dealerscore < playerscore && playerscore > 21) //win lose conditions
                    {
                        L++; //add one lost to scoreboard
                        tLose.Text = L.ToString();

                        MessageBox.Show("Dealer Wins!!", "Lost!", MessageBoxButtons.OK);
                    //         winGame = "Wenner";
                    //goto Einde; //if condition is met go to end marker
                    return;
                    }

                    else if (dealerscore > playerscore && dealerscore < 22) //win lose condition
                    {
                        L++;
                        tLose.Text = L.ToString();

                        MessageBox.Show("Dealer Wins!!", "Lost!", MessageBoxButtons.OK);
                 //       winGame = "Wenner";
                        //goto Einde;
                    }

                    else if (dealerscore == playerscore && playerscore < 22) // draw condition
                    {
                        D++; //add one draw to scoreboard
                        tDraw.Text = D.ToString();

                        MessageBox.Show("It's a tie!!", "Draw!", MessageBoxButtons.OK);
                   //     winGame = "Wenner";
                       // goto Einde;
                    }

                    else if (dealerscore > 21 && playerscore > 21) //win lose condition
                    {
                        L++;
                        tLose.Text = L.ToString();

                        MessageBox.Show("Dealer Wins!!", "Lost!", MessageBoxButtons.OK);
                     //   winGame = "Wenner"; 
                       // goto Einde;
                    }

                    else if (playerscore > 21) //lose condition
                    {
                        L++;
                        tLose.Text = L.ToString();

                        MessageBox.Show("Dealer Wins!!", "Lost!", MessageBoxButtons.OK);
                       // winGame = "Wenner"; 
                        //goto Einde;
                    }

                    else if (dealerscore < playerscore && playerscore < 22) //win lose condition
                    {
                        W++; //add win to scoreboard
                        tWin.Text = W.ToString();

                        MessageBox.Show("You Win!!", "Winner!", MessageBoxButtons.OK);
                    //winGame = "Wenner"; 
                    //    goto Einde;
                        var intVal = Convert.ToInt32(totalChips.Text);
                        WenChips = intVal + (betAmount * 2);
                        totalChips.Text = WenChips.ToString();
                    }

                    else if (dealerscore == playerscore && dealerscore > 21) //win los condition
                    {
                        L++;
                        tLose.Text = L.ToString();

                        MessageBox.Show("Dealer Wins!!", "Lost!", MessageBoxButtons.OK);
                        //winGame = "Wenner"; 
                      //  goto Einde;
                    }

                    else if (dealerscore > 21 && playerscore < 22) //win lose condition
                    {
                        W++;
                        tWin.Text = W.ToString();

                        MessageBox.Show("You Win!!", "Winner!", MessageBoxButtons.OK);
                    //winGame = "Wenner"; 
                    //goto Einde;
                        var intVal = Convert.ToInt32(totalChips.Text);
                        WenChips = intVal + (betAmount * 2);
                        totalChips.Text = WenChips.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Error", "Error", MessageBoxButtons.OK);
                    }

                }
           // Einde:; //end marker
            //}
        }
        private void quit_Click(object sender, EventArgs e) //quit the program when button is hit
        {
            if (MessageBox.Show("Are you sure you want to return to Main Menu?", "Main Menu", MessageBoxButtons.YesNo) == (DialogResult.Yes))
            {
                Properties.Settings.Default.SaveCoins = totalChips.Text;
                Properties.Settings.Default.Save();
                passingBackLabel = totalChips.Text;
                this.Hide(); //hides the start form
                BlackJack_start blackJack_Start = new BlackJack_start(); //creates a new form
                blackJack_Start.Show(); //shows the new form that is created

            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
                int chipVier = 500;
                betAmount += chipVier;

                BetAmountLbl.Text = betAmount.ToString();
        }

        private void chip25_Click(object sender, EventArgs e)
        {
                int chipEen = 2500;
                betAmount += chipEen;

                BetAmountLbl.Text = betAmount.ToString();
        }

        private void chip50_Click(object sender, EventArgs e)
        {
            int chipTwee = 50;
            betAmount += chipTwee;

            BetAmountLbl.Text = betAmount.ToString();
        }

        private void chip100_Click(object sender, EventArgs e)
        {   
            int chipDrie = 100;
            betAmount += chipDrie;

            BetAmountLbl.Text = betAmount.ToString();
            
        }

        private void chip1000_Click(object sender, EventArgs e)
        {
            int chipVyf = 1000;
            betAmount += chipVyf;

            BetAmountLbl.Text = betAmount.ToString();
        }

        private void ClearBet_Click(object sender, EventArgs e)
        {
                betAmount = 0;
                BetAmountLbl.Text = betAmount.ToString();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.SaveCoins = totalChips.Text;
            Properties.Settings.Default.Save();
        }
    }
}
