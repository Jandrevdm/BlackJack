﻿namespace BlackJack
{
    partial class BlackJack_start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BlackJack_start));
            this.button1 = new System.Windows.Forms.Button();
            this.help = new System.Windows.Forms.Button();
            this.quit = new System.Windows.Forms.Button();
            this.totalChips = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelBuy = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.largeBuyChips = new System.Windows.Forms.PictureBox();
            this.mediumBuyChips = new System.Windows.Forms.PictureBox();
            this.smallBuyChips = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timerlbl = new System.Windows.Forms.Label();
            this.FreeReward = new System.Windows.Forms.Button();
            this.EnableRedeem = new System.Windows.Forms.Label();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.raiseEmbtn = new System.Windows.Forms.Button();
            this.begingame = new System.Windows.Forms.Button();
            this.closeInfo = new System.Windows.Forms.Button();
            this.textBoxSupport = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelBuy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.largeBuyChips)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediumBuyChips)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smallBuyChips)).BeginInit();
            this.panelInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(251, 201);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "START";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // help
            // 
            this.help.BackColor = System.Drawing.Color.Red;
            this.help.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.help.ForeColor = System.Drawing.Color.White;
            this.help.Location = new System.Drawing.Point(12, 12);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(85, 48);
            this.help.TabIndex = 1;
            this.help.Text = "HELP";
            this.help.UseVisualStyleBackColor = false;
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // quit
            // 
            this.quit.BackColor = System.Drawing.Color.Red;
            this.quit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quit.ForeColor = System.Drawing.Color.White;
            this.quit.Location = new System.Drawing.Point(505, 12);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(85, 48);
            this.quit.TabIndex = 2;
            this.quit.Text = "QUIT";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // totalChips
            // 
            this.totalChips.AutoSize = true;
            this.totalChips.BackColor = System.Drawing.Color.Yellow;
            this.totalChips.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalChips.Location = new System.Drawing.Point(326, 46);
            this.totalChips.Name = "totalChips";
            this.totalChips.Size = new System.Drawing.Size(40, 24);
            this.totalChips.TabIndex = 44;
            this.totalChips.Text = "100";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::BlackJack.Properties.Resources.Stackchips;
            this.pictureBox1.Location = new System.Drawing.Point(238, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panelBuy
            // 
            this.panelBuy.BackgroundImage = global::BlackJack.Properties.Resources.cashier1;
            this.panelBuy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelBuy.Controls.Add(this.button4);
            this.panelBuy.Controls.Add(this.label3);
            this.panelBuy.Controls.Add(this.label2);
            this.panelBuy.Controls.Add(this.label1);
            this.panelBuy.Controls.Add(this.largeBuyChips);
            this.panelBuy.Controls.Add(this.mediumBuyChips);
            this.panelBuy.Controls.Add(this.smallBuyChips);
            this.panelBuy.Location = new System.Drawing.Point(12, 87);
            this.panelBuy.Name = "panelBuy";
            this.panelBuy.Size = new System.Drawing.Size(578, 239);
            this.panelBuy.TabIndex = 46;
            this.panelBuy.Visible = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(253, 9);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(85, 48);
            this.button4.TabIndex = 48;
            this.button4.Text = "CLOSE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(478, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 25);
            this.label3.TabIndex = 46;
            this.label3.Text = "100 000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(254, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 25);
            this.label2.TabIndex = 45;
            this.label2.Text = "10 000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(28, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 25);
            this.label1.TabIndex = 44;
            this.label1.Text = "1000";
            // 
            // largeBuyChips
            // 
            this.largeBuyChips.BackColor = System.Drawing.Color.Transparent;
            this.largeBuyChips.Image = global::BlackJack.Properties.Resources.Stackchips1;
            this.largeBuyChips.Location = new System.Drawing.Point(449, 63);
            this.largeBuyChips.Name = "largeBuyChips";
            this.largeBuyChips.Size = new System.Drawing.Size(135, 82);
            this.largeBuyChips.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.largeBuyChips.TabIndex = 43;
            this.largeBuyChips.TabStop = false;
            this.largeBuyChips.Click += new System.EventHandler(this.largeBuyChips_Click);
            // 
            // mediumBuyChips
            // 
            this.mediumBuyChips.BackColor = System.Drawing.Color.Transparent;
            this.mediumBuyChips.Image = global::BlackJack.Properties.Resources.medium_stack;
            this.mediumBuyChips.Location = new System.Drawing.Point(232, 63);
            this.mediumBuyChips.Name = "mediumBuyChips";
            this.mediumBuyChips.Size = new System.Drawing.Size(135, 82);
            this.mediumBuyChips.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mediumBuyChips.TabIndex = 42;
            this.mediumBuyChips.TabStop = false;
            this.mediumBuyChips.Click += new System.EventHandler(this.mediumBuyChips_Click);
            // 
            // smallBuyChips
            // 
            this.smallBuyChips.BackColor = System.Drawing.Color.Transparent;
            this.smallBuyChips.Image = global::BlackJack.Properties.Resources.smallstack;
            this.smallBuyChips.Location = new System.Drawing.Point(-5, 63);
            this.smallBuyChips.Name = "smallBuyChips";
            this.smallBuyChips.Size = new System.Drawing.Size(135, 82);
            this.smallBuyChips.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.smallBuyChips.TabIndex = 41;
            this.smallBuyChips.TabStop = false;
            this.smallBuyChips.Click += new System.EventHandler(this.smallBuyChips_Click);
            // 
            // timerlbl
            // 
            this.timerlbl.AutoSize = true;
            this.timerlbl.Location = new System.Drawing.Point(134, 31);
            this.timerlbl.Name = "timerlbl";
            this.timerlbl.Size = new System.Drawing.Size(35, 13);
            this.timerlbl.TabIndex = 47;
            this.timerlbl.Text = "label4";
            this.timerlbl.Visible = false;
            // 
            // FreeReward
            // 
            this.FreeReward.BackColor = System.Drawing.Color.Transparent;
            this.FreeReward.BackgroundImage = global::BlackJack.Properties.Resources.start;
            this.FreeReward.FlatAppearance.BorderSize = 0;
            this.FreeReward.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FreeReward.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FreeReward.ForeColor = System.Drawing.Color.Yellow;
            this.FreeReward.Location = new System.Drawing.Point(164, 30);
            this.FreeReward.Name = "FreeReward";
            this.FreeReward.Size = new System.Drawing.Size(82, 51);
            this.FreeReward.TabIndex = 48;
            this.FreeReward.Text = "Free Reward";
            this.FreeReward.UseVisualStyleBackColor = false;
            this.FreeReward.Click += new System.EventHandler(this.FreeReward_Click);
            // 
            // EnableRedeem
            // 
            this.EnableRedeem.AutoSize = true;
            this.EnableRedeem.Location = new System.Drawing.Point(134, 54);
            this.EnableRedeem.Name = "EnableRedeem";
            this.EnableRedeem.Size = new System.Drawing.Size(13, 13);
            this.EnableRedeem.TabIndex = 49;
            this.EnableRedeem.Text = "0";
            this.EnableRedeem.Visible = false;
            // 
            // panelInfo
            // 
            this.panelInfo.Controls.Add(this.raiseEmbtn);
            this.panelInfo.Controls.Add(this.begingame);
            this.panelInfo.Controls.Add(this.closeInfo);
            this.panelInfo.Controls.Add(this.textBoxSupport);
            this.panelInfo.Location = new System.Drawing.Point(12, 12);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(578, 314);
            this.panelInfo.TabIndex = 50;
            this.panelInfo.Visible = false;
            // 
            // raiseEmbtn
            // 
            this.raiseEmbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("raiseEmbtn.BackgroundImage")));
            this.raiseEmbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.raiseEmbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raiseEmbtn.ForeColor = System.Drawing.Color.Yellow;
            this.raiseEmbtn.Location = new System.Drawing.Point(360, 75);
            this.raiseEmbtn.Name = "raiseEmbtn";
            this.raiseEmbtn.Size = new System.Drawing.Size(174, 76);
            this.raiseEmbtn.TabIndex = 53;
            this.raiseEmbtn.Text = "Coming Soon!\r\nRaise-Em Poker";
            this.raiseEmbtn.UseVisualStyleBackColor = true;
            this.raiseEmbtn.Click += new System.EventHandler(this.raiseEmbtn_Click);
            // 
            // begingame
            // 
            this.begingame.BackColor = System.Drawing.Color.Green;
            this.begingame.Location = new System.Drawing.Point(553, 34);
            this.begingame.Name = "begingame";
            this.begingame.Size = new System.Drawing.Size(22, 274);
            this.begingame.TabIndex = 2;
            this.begingame.Text = "START";
            this.begingame.UseVisualStyleBackColor = false;
            this.begingame.Click += new System.EventHandler(this.begingame_Click);
            // 
            // closeInfo
            // 
            this.closeInfo.BackColor = System.Drawing.Color.Red;
            this.closeInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeInfo.Location = new System.Drawing.Point(553, 3);
            this.closeInfo.Name = "closeInfo";
            this.closeInfo.Size = new System.Drawing.Size(22, 23);
            this.closeInfo.TabIndex = 1;
            this.closeInfo.Text = "X";
            this.closeInfo.UseVisualStyleBackColor = false;
            this.closeInfo.Click += new System.EventHandler(this.closeInfo_Click);
            // 
            // textBoxSupport
            // 
            this.textBoxSupport.Location = new System.Drawing.Point(0, 0);
            this.textBoxSupport.Multiline = true;
            this.textBoxSupport.Name = "textBoxSupport";
            this.textBoxSupport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxSupport.Size = new System.Drawing.Size(552, 308);
            this.textBoxSupport.TabIndex = 0;
            this.textBoxSupport.Text = resources.GetString("textBoxSupport.Text");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(534, 310);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 16);
            this.label5.TabIndex = 52;
            this.label5.Text = "v1.0.0.0.1";
            // 
            // BlackJack_start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(602, 335);
            this.Controls.Add(this.panelInfo);
            this.Controls.Add(this.EnableRedeem);
            this.Controls.Add(this.FreeReward);
            this.Controls.Add(this.timerlbl);
            this.Controls.Add(this.panelBuy);
            this.Controls.Add(this.totalChips);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.quit);
            this.Controls.Add(this.help);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Name = "BlackJack_start";
            this.Text = "BlackJack_start";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BlackJack_start_FormClosing);
            this.Load += new System.EventHandler(this.BlackJack_start_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelBuy.ResumeLayout(false);
            this.panelBuy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.largeBuyChips)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mediumBuyChips)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smallBuyChips)).EndInit();
            this.panelInfo.ResumeLayout(false);
            this.panelInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Label totalChips;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelBuy;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox largeBuyChips;
        private System.Windows.Forms.PictureBox mediumBuyChips;
        private System.Windows.Forms.PictureBox smallBuyChips;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label timerlbl;
        private System.Windows.Forms.Button FreeReward;
        private System.Windows.Forms.Label EnableRedeem;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.TextBox textBoxSupport;
        private System.Windows.Forms.Button closeInfo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button begingame;
        private System.Windows.Forms.Button raiseEmbtn;
    }
}