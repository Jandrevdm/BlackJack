﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack
{
    public partial class RaiseEm : Form
    {
        public RaiseEm()
        {
            InitializeComponent();
        }

        public static string passingBackLabel;

        public void RaiseEm_Load(object sender, EventArgs e)
        {
            totalChips.Text = BlackJack_start.passingLabel;

        }

        private void quit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to return to Main Menu?", "Main Menu", MessageBoxButtons.YesNo) == (DialogResult.Yes))
            {
                Properties.Settings.Default.SaveCoins = totalChips.Text;
                Properties.Settings.Default.Save();
                passingBackLabel = totalChips.Text;
                this.Hide(); //hides the start form
                BlackJack_start blackJack_Start = new BlackJack_start(); //creates a new form
                blackJack_Start.Show(); //shows the new form that is created

            }
        }

        private void RaiseEm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.SaveCoins = totalChips.Text;
            Properties.Settings.Default.Save();
        }
    }
}
