﻿namespace BlackJack
{
    partial class RaiseEm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RaiseEm));
            this.quit = new System.Windows.Forms.Button();
            this.totalChips = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dealer1 = new System.Windows.Forms.PictureBox();
            this.dealer2 = new System.Windows.Forms.PictureBox();
            this.player1 = new System.Windows.Forms.PictureBox();
            this.player2 = new System.Windows.Forms.PictureBox();
            this.player3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player3)).BeginInit();
            this.SuspendLayout();
            // 
            // quit
            // 
            this.quit.BackColor = System.Drawing.Color.Red;
            this.quit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quit.Location = new System.Drawing.Point(12, 12);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(114, 61);
            this.quit.TabIndex = 34;
            this.quit.Text = "MAIN MENU";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // totalChips
            // 
            this.totalChips.AutoSize = true;
            this.totalChips.BackColor = System.Drawing.Color.Yellow;
            this.totalChips.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalChips.Location = new System.Drawing.Point(432, 388);
            this.totalChips.Name = "totalChips";
            this.totalChips.Size = new System.Drawing.Size(50, 24);
            this.totalChips.TabIndex = 44;
            this.totalChips.Text = "1000";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::BlackJack.Properties.Resources.Stackchips;
            this.pictureBox1.Location = new System.Drawing.Point(336, 360);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // dealer1
            // 
            this.dealer1.BackColor = System.Drawing.Color.Transparent;
            this.dealer1.Location = new System.Drawing.Point(336, 115);
            this.dealer1.Name = "dealer1";
            this.dealer1.Size = new System.Drawing.Size(50, 70);
            this.dealer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer1.TabIndex = 45;
            this.dealer1.TabStop = false;
            this.dealer1.Visible = false;
            // 
            // dealer2
            // 
            this.dealer2.BackColor = System.Drawing.Color.Transparent;
            this.dealer2.Location = new System.Drawing.Point(423, 115);
            this.dealer2.Name = "dealer2";
            this.dealer2.Size = new System.Drawing.Size(50, 70);
            this.dealer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer2.TabIndex = 46;
            this.dealer2.TabStop = false;
            this.dealer2.Visible = false;
            // 
            // player1
            // 
            this.player1.BackColor = System.Drawing.Color.Transparent;
            this.player1.Location = new System.Drawing.Point(338, 226);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(50, 70);
            this.player1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player1.TabIndex = 47;
            this.player1.TabStop = false;
            this.player1.Visible = false;
            // 
            // player2
            // 
            this.player2.BackColor = System.Drawing.Color.Transparent;
            this.player2.Location = new System.Drawing.Point(386, 226);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(50, 70);
            this.player2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player2.TabIndex = 48;
            this.player2.TabStop = false;
            this.player2.Visible = false;
            // 
            // player3
            // 
            this.player3.BackColor = System.Drawing.Color.Transparent;
            this.player3.Location = new System.Drawing.Point(435, 226);
            this.player3.Name = "player3";
            this.player3.Size = new System.Drawing.Size(50, 70);
            this.player3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player3.TabIndex = 49;
            this.player3.TabStop = false;
            this.player3.Visible = false;
            // 
            // RaiseEm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.player3);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.dealer2);
            this.Controls.Add(this.dealer1);
            this.Controls.Add(this.totalChips);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.quit);
            this.Name = "RaiseEm";
            this.Text = "RaiseEm";
            this.Load += new System.EventHandler(this.RaiseEm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.Label totalChips;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox dealer1;
        private System.Windows.Forms.PictureBox dealer2;
        private System.Windows.Forms.PictureBox player1;
        private System.Windows.Forms.PictureBox player2;
        private System.Windows.Forms.PictureBox player3;
    }
}