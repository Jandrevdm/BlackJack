﻿using System;

namespace BlackJack
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Dealer = new System.Windows.Forms.Label();
            this.Player = new System.Windows.Forms.Label();
            this.Win = new System.Windows.Forms.Label();
            this.Draw = new System.Windows.Forms.Label();
            this.Lose = new System.Windows.Forms.Label();
            this.dealer1 = new System.Windows.Forms.PictureBox();
            this.dealer2 = new System.Windows.Forms.PictureBox();
            this.dealer3 = new System.Windows.Forms.PictureBox();
            this.dealer4 = new System.Windows.Forms.PictureBox();
            this.dealer5 = new System.Windows.Forms.PictureBox();
            this.dealer6 = new System.Windows.Forms.PictureBox();
            this.dealer7 = new System.Windows.Forms.PictureBox();
            this.player1 = new System.Windows.Forms.PictureBox();
            this.player2 = new System.Windows.Forms.PictureBox();
            this.player3 = new System.Windows.Forms.PictureBox();
            this.player4 = new System.Windows.Forms.PictureBox();
            this.player5 = new System.Windows.Forms.PictureBox();
            this.player6 = new System.Windows.Forms.PictureBox();
            this.player7 = new System.Windows.Forms.PictureBox();
            this.hit = new System.Windows.Forms.Button();
            this.stand = new System.Windows.Forms.Button();
            this.scoreDealer = new System.Windows.Forms.Label();
            this.scorePlayer = new System.Windows.Forms.Label();
            this.tWin = new System.Windows.Forms.Label();
            this.tDraw = new System.Windows.Forms.Label();
            this.tLose = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.DEAL = new System.Windows.Forms.Button();
            this.playerbust = new System.Windows.Forms.Label();
            this.dealerbust = new System.Windows.Forms.Label();
            this.quit = new System.Windows.Forms.Button();
            this.chip25 = new System.Windows.Forms.PictureBox();
            this.chip50 = new System.Windows.Forms.PictureBox();
            this.chip1000 = new System.Windows.Forms.PictureBox();
            this.chip500 = new System.Windows.Forms.PictureBox();
            this.chip100 = new System.Windows.Forms.PictureBox();
            this.BetAmountLbl = new System.Windows.Forms.Label();
            this.ClearBet = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.totalChips = new System.Windows.Forms.Label();
            this.pictureBoxBets = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dealer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player7)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chip25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip1000)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip500)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBets)).BeginInit();
            this.SuspendLayout();
            // 
            // Dealer
            // 
            this.Dealer.AutoSize = true;
            this.Dealer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Dealer.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer.ForeColor = System.Drawing.Color.White;
            this.Dealer.Location = new System.Drawing.Point(499, 9);
            this.Dealer.Name = "Dealer";
            this.Dealer.Size = new System.Drawing.Size(107, 33);
            this.Dealer.TabIndex = 0;
            this.Dealer.Text = "Dealer";
            // 
            // Player
            // 
            this.Player.AutoSize = true;
            this.Player.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Player.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player.ForeColor = System.Drawing.Color.White;
            this.Player.Location = new System.Drawing.Point(502, 658);
            this.Player.Name = "Player";
            this.Player.Size = new System.Drawing.Size(104, 33);
            this.Player.TabIndex = 1;
            this.Player.Text = "Player";
            // 
            // Win
            // 
            this.Win.AutoSize = true;
            this.Win.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Win.Location = new System.Drawing.Point(23, 13);
            this.Win.Name = "Win";
            this.Win.Size = new System.Drawing.Size(31, 16);
            this.Win.TabIndex = 2;
            this.Win.Text = "Win";
            // 
            // Draw
            // 
            this.Draw.AutoSize = true;
            this.Draw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Draw.Location = new System.Drawing.Point(23, 44);
            this.Draw.Name = "Draw";
            this.Draw.Size = new System.Drawing.Size(39, 16);
            this.Draw.TabIndex = 3;
            this.Draw.Text = "Draw";
            // 
            // Lose
            // 
            this.Lose.AutoSize = true;
            this.Lose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lose.Location = new System.Drawing.Point(23, 76);
            this.Lose.Name = "Lose";
            this.Lose.Size = new System.Drawing.Size(38, 16);
            this.Lose.TabIndex = 4;
            this.Lose.Text = "Lose";
            // 
            // dealer1
            // 
            this.dealer1.BackColor = System.Drawing.Color.Transparent;
            this.dealer1.Location = new System.Drawing.Point(393, 46);
            this.dealer1.Name = "dealer1";
            this.dealer1.Size = new System.Drawing.Size(50, 70);
            this.dealer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer1.TabIndex = 5;
            this.dealer1.TabStop = false;
            this.dealer1.Visible = false;
            // 
            // dealer2
            // 
            this.dealer2.BackColor = System.Drawing.Color.Transparent;
            this.dealer2.Image = global::BlackJack.Properties.Resources.CardBack;
            this.dealer2.Location = new System.Drawing.Point(429, 46);
            this.dealer2.Name = "dealer2";
            this.dealer2.Size = new System.Drawing.Size(79, 123);
            this.dealer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer2.TabIndex = 6;
            this.dealer2.TabStop = false;
            this.dealer2.Visible = false;
            this.dealer2.WaitOnLoad = true;
            // 
            // dealer3
            // 
            this.dealer3.BackColor = System.Drawing.Color.Transparent;
            this.dealer3.Location = new System.Drawing.Point(485, 46);
            this.dealer3.Name = "dealer3";
            this.dealer3.Size = new System.Drawing.Size(50, 70);
            this.dealer3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer3.TabIndex = 7;
            this.dealer3.TabStop = false;
            this.dealer3.Visible = false;
            // 
            // dealer4
            // 
            this.dealer4.BackColor = System.Drawing.Color.Transparent;
            this.dealer4.Location = new System.Drawing.Point(541, 45);
            this.dealer4.Name = "dealer4";
            this.dealer4.Size = new System.Drawing.Size(50, 70);
            this.dealer4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer4.TabIndex = 8;
            this.dealer4.TabStop = false;
            this.dealer4.Visible = false;
            // 
            // dealer5
            // 
            this.dealer5.BackColor = System.Drawing.Color.Transparent;
            this.dealer5.Location = new System.Drawing.Point(597, 46);
            this.dealer5.Name = "dealer5";
            this.dealer5.Size = new System.Drawing.Size(50, 70);
            this.dealer5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer5.TabIndex = 9;
            this.dealer5.TabStop = false;
            this.dealer5.Visible = false;
            // 
            // dealer6
            // 
            this.dealer6.BackColor = System.Drawing.Color.Transparent;
            this.dealer6.Location = new System.Drawing.Point(653, 46);
            this.dealer6.Name = "dealer6";
            this.dealer6.Size = new System.Drawing.Size(50, 70);
            this.dealer6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer6.TabIndex = 10;
            this.dealer6.TabStop = false;
            this.dealer6.Visible = false;
            // 
            // dealer7
            // 
            this.dealer7.BackColor = System.Drawing.Color.Transparent;
            this.dealer7.Location = new System.Drawing.Point(709, 45);
            this.dealer7.Name = "dealer7";
            this.dealer7.Size = new System.Drawing.Size(50, 70);
            this.dealer7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.dealer7.TabIndex = 11;
            this.dealer7.TabStop = false;
            this.dealer7.Visible = false;
            // 
            // player1
            // 
            this.player1.BackColor = System.Drawing.Color.Transparent;
            this.player1.Location = new System.Drawing.Point(505, 460);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(50, 70);
            this.player1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player1.TabIndex = 12;
            this.player1.TabStop = false;
            this.player1.Visible = false;
            // 
            // player2
            // 
            this.player2.BackColor = System.Drawing.Color.Transparent;
            this.player2.Location = new System.Drawing.Point(522, 443);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(50, 70);
            this.player2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player2.TabIndex = 13;
            this.player2.TabStop = false;
            this.player2.Visible = false;
            // 
            // player3
            // 
            this.player3.BackColor = System.Drawing.Color.Transparent;
            this.player3.Location = new System.Drawing.Point(537, 428);
            this.player3.Name = "player3";
            this.player3.Size = new System.Drawing.Size(50, 70);
            this.player3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player3.TabIndex = 14;
            this.player3.TabStop = false;
            this.player3.Visible = false;
            // 
            // player4
            // 
            this.player4.BackColor = System.Drawing.Color.Transparent;
            this.player4.Location = new System.Drawing.Point(552, 413);
            this.player4.Name = "player4";
            this.player4.Size = new System.Drawing.Size(50, 70);
            this.player4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player4.TabIndex = 15;
            this.player4.TabStop = false;
            this.player4.Visible = false;
            // 
            // player5
            // 
            this.player5.BackColor = System.Drawing.Color.Transparent;
            this.player5.Location = new System.Drawing.Point(567, 398);
            this.player5.Name = "player5";
            this.player5.Size = new System.Drawing.Size(50, 70);
            this.player5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player5.TabIndex = 16;
            this.player5.TabStop = false;
            this.player5.Visible = false;
            // 
            // player6
            // 
            this.player6.BackColor = System.Drawing.Color.Transparent;
            this.player6.Location = new System.Drawing.Point(582, 383);
            this.player6.Name = "player6";
            this.player6.Size = new System.Drawing.Size(50, 70);
            this.player6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player6.TabIndex = 17;
            this.player6.TabStop = false;
            this.player6.Visible = false;
            // 
            // player7
            // 
            this.player7.BackColor = System.Drawing.Color.Transparent;
            this.player7.Location = new System.Drawing.Point(597, 368);
            this.player7.Name = "player7";
            this.player7.Size = new System.Drawing.Size(50, 70);
            this.player7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.player7.TabIndex = 18;
            this.player7.TabStop = false;
            this.player7.Visible = false;
            // 
            // hit
            // 
            this.hit.BackColor = System.Drawing.Color.Yellow;
            this.hit.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hit.Location = new System.Drawing.Point(48, 484);
            this.hit.Name = "hit";
            this.hit.Size = new System.Drawing.Size(165, 83);
            this.hit.TabIndex = 19;
            this.hit.Text = "HIT";
            this.hit.UseVisualStyleBackColor = false;
            this.hit.Visible = false;
            this.hit.Click += new System.EventHandler(this.button1_Click);
            // 
            // stand
            // 
            this.stand.BackColor = System.Drawing.Color.Yellow;
            this.stand.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stand.Location = new System.Drawing.Point(879, 484);
            this.stand.Name = "stand";
            this.stand.Size = new System.Drawing.Size(165, 83);
            this.stand.TabIndex = 20;
            this.stand.Text = "STAND";
            this.stand.UseVisualStyleBackColor = false;
            this.stand.Visible = false;
            this.stand.Click += new System.EventHandler(this.stand_Click);
            // 
            // scoreDealer
            // 
            this.scoreDealer.AutoSize = true;
            this.scoreDealer.BackColor = System.Drawing.Color.Lime;
            this.scoreDealer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreDealer.Location = new System.Drawing.Point(533, 189);
            this.scoreDealer.Name = "scoreDealer";
            this.scoreDealer.Size = new System.Drawing.Size(128, 25);
            this.scoreDealer.TabIndex = 21;
            this.scoreDealer.Text = "scoreDealer";
            // 
            // scorePlayer
            // 
            this.scorePlayer.AutoSize = true;
            this.scorePlayer.BackColor = System.Drawing.Color.Lime;
            this.scorePlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scorePlayer.Location = new System.Drawing.Point(462, 501);
            this.scorePlayer.Name = "scorePlayer";
            this.scorePlayer.Size = new System.Drawing.Size(126, 25);
            this.scorePlayer.TabIndex = 22;
            this.scorePlayer.Text = "scorePlayer";
            // 
            // tWin
            // 
            this.tWin.AutoSize = true;
            this.tWin.BackColor = System.Drawing.Color.White;
            this.tWin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tWin.Location = new System.Drawing.Point(86, 13);
            this.tWin.Name = "tWin";
            this.tWin.Size = new System.Drawing.Size(15, 16);
            this.tWin.TabIndex = 23;
            this.tWin.Text = "0";
            this.tWin.Click += new System.EventHandler(this.tWin_Click);
            // 
            // tDraw
            // 
            this.tDraw.AutoSize = true;
            this.tDraw.BackColor = System.Drawing.Color.White;
            this.tDraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tDraw.Location = new System.Drawing.Point(86, 44);
            this.tDraw.Name = "tDraw";
            this.tDraw.Size = new System.Drawing.Size(15, 16);
            this.tDraw.TabIndex = 24;
            this.tDraw.Text = "0";
            // 
            // tLose
            // 
            this.tLose.AutoSize = true;
            this.tLose.BackColor = System.Drawing.Color.White;
            this.tLose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tLose.Location = new System.Drawing.Point(86, 76);
            this.tLose.Name = "tLose";
            this.tLose.Size = new System.Drawing.Size(15, 16);
            this.tLose.TabIndex = 25;
            this.tLose.Text = "0";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Controls.Add(this.tWin);
            this.panel1.Controls.Add(this.tDraw);
            this.panel1.Controls.Add(this.tLose);
            this.panel1.Controls.Add(this.Win);
            this.panel1.Controls.Add(this.Draw);
            this.panel1.Controls.Add(this.Lose);
            this.panel1.Location = new System.Drawing.Point(941, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(153, 100);
            this.panel1.TabIndex = 26;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(485, 270);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(171, 92);
            this.button1.TabIndex = 27;
            this.button1.Text = "PLAY AGAIN";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // DEAL
            // 
            this.DEAL.BackColor = System.Drawing.Color.Aqua;
            this.DEAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DEAL.ForeColor = System.Drawing.Color.Navy;
            this.DEAL.Location = new System.Drawing.Point(485, 269);
            this.DEAL.Name = "DEAL";
            this.DEAL.Size = new System.Drawing.Size(171, 96);
            this.DEAL.TabIndex = 30;
            this.DEAL.Text = "DEAL";
            this.DEAL.UseVisualStyleBackColor = false;
            this.DEAL.Click += new System.EventHandler(this.DEAL_Click);
            // 
            // playerbust
            // 
            this.playerbust.AutoSize = true;
            this.playerbust.BackColor = System.Drawing.Color.Black;
            this.playerbust.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerbust.ForeColor = System.Drawing.Color.White;
            this.playerbust.Location = new System.Drawing.Point(493, 501);
            this.playerbust.Name = "playerbust";
            this.playerbust.Size = new System.Drawing.Size(113, 39);
            this.playerbust.TabIndex = 31;
            this.playerbust.Text = "BUST";
            this.playerbust.Visible = false;
            // 
            // dealerbust
            // 
            this.dealerbust.AutoSize = true;
            this.dealerbust.BackColor = System.Drawing.Color.Black;
            this.dealerbust.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dealerbust.ForeColor = System.Drawing.Color.White;
            this.dealerbust.Location = new System.Drawing.Point(494, 88);
            this.dealerbust.Name = "dealerbust";
            this.dealerbust.Size = new System.Drawing.Size(113, 39);
            this.dealerbust.TabIndex = 32;
            this.dealerbust.Text = "BUST";
            this.dealerbust.Visible = false;
            // 
            // quit
            // 
            this.quit.BackColor = System.Drawing.Color.Red;
            this.quit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quit.Location = new System.Drawing.Point(12, 9);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(114, 61);
            this.quit.TabIndex = 33;
            this.quit.Text = "MAIN MENU";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.quit_Click);
            // 
            // chip25
            // 
            this.chip25.BackColor = System.Drawing.Color.Transparent;
            this.chip25.Image = global::BlackJack.Properties.Resources.chip2500;
            this.chip25.Location = new System.Drawing.Point(672, 600);
            this.chip25.Name = "chip25";
            this.chip25.Size = new System.Drawing.Size(113, 54);
            this.chip25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chip25.TabIndex = 34;
            this.chip25.TabStop = false;
            this.chip25.Click += new System.EventHandler(this.chip25_Click);
            // 
            // chip50
            // 
            this.chip50.BackColor = System.Drawing.Color.Transparent;
            this.chip50.Image = global::BlackJack.Properties.Resources.chip50;
            this.chip50.Location = new System.Drawing.Point(330, 600);
            this.chip50.Name = "chip50";
            this.chip50.Size = new System.Drawing.Size(113, 54);
            this.chip50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chip50.TabIndex = 35;
            this.chip50.TabStop = false;
            this.chip50.Click += new System.EventHandler(this.chip50_Click);
            // 
            // chip1000
            // 
            this.chip1000.BackColor = System.Drawing.Color.Transparent;
            this.chip1000.Image = global::BlackJack.Properties.Resources.chip1000;
            this.chip1000.Location = new System.Drawing.Point(582, 600);
            this.chip1000.Name = "chip1000";
            this.chip1000.Size = new System.Drawing.Size(113, 54);
            this.chip1000.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chip1000.TabIndex = 36;
            this.chip1000.TabStop = false;
            this.chip1000.Click += new System.EventHandler(this.chip1000_Click);
            // 
            // chip500
            // 
            this.chip500.BackColor = System.Drawing.Color.Transparent;
            this.chip500.Image = global::BlackJack.Properties.Resources.chip500;
            this.chip500.Location = new System.Drawing.Point(494, 601);
            this.chip500.Name = "chip500";
            this.chip500.Size = new System.Drawing.Size(113, 54);
            this.chip500.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chip500.TabIndex = 37;
            this.chip500.TabStop = false;
            this.chip500.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // chip100
            // 
            this.chip100.BackColor = System.Drawing.Color.Transparent;
            this.chip100.Image = global::BlackJack.Properties.Resources.chip100;
            this.chip100.Location = new System.Drawing.Point(413, 600);
            this.chip100.Name = "chip100";
            this.chip100.Size = new System.Drawing.Size(113, 54);
            this.chip100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chip100.TabIndex = 38;
            this.chip100.TabStop = false;
            this.chip100.Click += new System.EventHandler(this.chip100_Click);
            // 
            // BetAmountLbl
            // 
            this.BetAmountLbl.AutoSize = true;
            this.BetAmountLbl.BackColor = System.Drawing.Color.Transparent;
            this.BetAmountLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BetAmountLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BetAmountLbl.ForeColor = System.Drawing.Color.Yellow;
            this.BetAmountLbl.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BetAmountLbl.Location = new System.Drawing.Point(535, 589);
            this.BetAmountLbl.Name = "BetAmountLbl";
            this.BetAmountLbl.Size = new System.Drawing.Size(19, 20);
            this.BetAmountLbl.TabIndex = 39;
            this.BetAmountLbl.Text = "0";
            // 
            // ClearBet
            // 
            this.ClearBet.BackColor = System.Drawing.Color.Blue;
            this.ClearBet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearBet.ForeColor = System.Drawing.Color.White;
            this.ClearBet.Location = new System.Drawing.Point(278, 610);
            this.ClearBet.Name = "ClearBet";
            this.ClearBet.Size = new System.Drawing.Size(75, 28);
            this.ClearBet.TabIndex = 40;
            this.ClearBet.Text = "Clear bet\r\n";
            this.ClearBet.UseVisualStyleBackColor = false;
            this.ClearBet.Click += new System.EventHandler(this.ClearBet_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::BlackJack.Properties.Resources.Stackchips;
            this.pictureBox1.Location = new System.Drawing.Point(608, 630);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // totalChips
            // 
            this.totalChips.AutoSize = true;
            this.totalChips.BackColor = System.Drawing.Color.Yellow;
            this.totalChips.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalChips.Location = new System.Drawing.Point(704, 658);
            this.totalChips.Name = "totalChips";
            this.totalChips.Size = new System.Drawing.Size(50, 24);
            this.totalChips.TabIndex = 42;
            this.totalChips.Text = "1000";
            // 
            // pictureBoxBets
            // 
            this.pictureBoxBets.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBets.Image = global::BlackJack.Properties.Resources.Stackchips;
            this.pictureBoxBets.Location = new System.Drawing.Point(469, 564);
            this.pictureBoxBets.Name = "pictureBoxBets";
            this.pictureBoxBets.Size = new System.Drawing.Size(150, 91);
            this.pictureBoxBets.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBets.TabIndex = 43;
            this.pictureBoxBets.TabStop = false;
            this.pictureBoxBets.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1096, 709);
            this.Controls.Add(this.BetAmountLbl);
            this.Controls.Add(this.ClearBet);
            this.Controls.Add(this.totalChips);
            this.Controls.Add(this.chip100);
            this.Controls.Add(this.chip500);
            this.Controls.Add(this.chip1000);
            this.Controls.Add(this.chip50);
            this.Controls.Add(this.chip25);
            this.Controls.Add(this.quit);
            this.Controls.Add(this.dealerbust);
            this.Controls.Add(this.playerbust);
            this.Controls.Add(this.dealer2);
            this.Controls.Add(this.player3);
            this.Controls.Add(this.player4);
            this.Controls.Add(this.player5);
            this.Controls.Add(this.player6);
            this.Controls.Add(this.player2);
            this.Controls.Add(this.DEAL);
            this.Controls.Add(this.dealer3);
            this.Controls.Add(this.dealer7);
            this.Controls.Add(this.dealer6);
            this.Controls.Add(this.dealer5);
            this.Controls.Add(this.dealer4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.scorePlayer);
            this.Controls.Add(this.scoreDealer);
            this.Controls.Add(this.stand);
            this.Controls.Add(this.hit);
            this.Controls.Add(this.dealer1);
            this.Controls.Add(this.Player);
            this.Controls.Add(this.Dealer);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.player7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBoxBets);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dealer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealer7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player7)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chip25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip1000)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip500)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chip100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void tWin_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label Dealer;
        private System.Windows.Forms.Label Player;
        private System.Windows.Forms.Label Win;
        private System.Windows.Forms.Label Draw;
        private System.Windows.Forms.Label Lose;
        private System.Windows.Forms.PictureBox dealer1;
        private System.Windows.Forms.PictureBox dealer2;
        private System.Windows.Forms.PictureBox dealer3;
        private System.Windows.Forms.PictureBox dealer4;
        private System.Windows.Forms.PictureBox dealer5;
        private System.Windows.Forms.PictureBox dealer6;
        private System.Windows.Forms.PictureBox dealer7;
        private System.Windows.Forms.PictureBox player1;
        private System.Windows.Forms.PictureBox player2;
        private System.Windows.Forms.PictureBox player3;
        private System.Windows.Forms.PictureBox player4;
        private System.Windows.Forms.PictureBox player5;
        private System.Windows.Forms.PictureBox player6;
        private System.Windows.Forms.PictureBox player7;
        private System.Windows.Forms.Button hit;
        private System.Windows.Forms.Button stand;
        private System.Windows.Forms.Label scoreDealer;
        private System.Windows.Forms.Label scorePlayer;
        private System.Windows.Forms.Label tWin;
        private System.Windows.Forms.Label tDraw;
        private System.Windows.Forms.Label tLose;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button DEAL;
        private System.Windows.Forms.Label playerbust;
        private System.Windows.Forms.Label dealerbust;
        private System.Windows.Forms.Button quit;
        private System.Windows.Forms.PictureBox chip25;
        private System.Windows.Forms.PictureBox chip50;
        private System.Windows.Forms.PictureBox chip1000;
        private System.Windows.Forms.PictureBox chip500;
        private System.Windows.Forms.PictureBox chip100;
        private System.Windows.Forms.Label BetAmountLbl;
        private System.Windows.Forms.Button ClearBet;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label totalChips;
        private System.Windows.Forms.PictureBox pictureBoxBets;
    }
}

