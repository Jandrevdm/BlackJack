﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Jandre van der Merwe
 * BLACKJACK start form
*/
namespace BlackJack
{
    public partial class BlackJack_start : Form
    {
        public static string passingLabel;
        public BlackJack_start()
        {
            InitializeComponent(); //starts the program's main form
            timer1.Start();
        }


        private void BlackJack_start_Load(object sender, EventArgs e)
        {
            //totalChips.Text = Form1.passingBackLabel;
            if (totalChips.Text == "")
            {
                totalChips.Text = "0";
            }


            if (EnableRedeem.Text == "1")
            {
                FreeReward.Visible = true;
            }
            else
            {
                FreeReward.Visible = false;
            }

            totalChips.Text = Properties.Settings.Default.SaveCoins;
            EnableRedeem.Text = Properties.Settings.Default.SaveRedeem;
        }

        private void BlackJack_start_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.SaveCoins = totalChips.Text;
            Properties.Settings.Default.SaveRedeem = EnableRedeem.Text;
            Properties.Settings.Default.Save();
        }

        private void button1_Click(object sender, EventArgs e) //the start button
        {
            passingLabel = totalChips.Text;
            this.Hide(); //hides the start form
            Form1 form1 = new Form1(); //creates a new form
            form1.Show(); //shows the new form that is created
            Properties.Settings.Default.SaveRedeem = EnableRedeem.Text;
            Properties.Settings.Default.Save();

        }
        private void help_Click(object sender, EventArgs e) //help button to show user what to do
        {
            panelInfo.Visible = true;

            if (MessageBox.Show("To start the game for the first time please press the long green button, then player must click on START button, The game will then open and the user " +
                "can click DEAL to draw the cards or QUIT to exit the game, the player can then either " +
                "HIT to deal another card or STAND to make the dealer pull cards for himself, a message will appear with the" +
                " Win/Lose " +"condition, to play again click the PLAY AGAIN button.", "Help", MessageBoxButtons.OK) ==
                DialogResult.OK); // displays a message box            
        }

        private void quit_Click(object sender, EventArgs e) //button to quit the program
        {
            
            if (MessageBox.Show("Are you sure you want to Quit?", "QUIT", MessageBoxButtons.YesNo) == (DialogResult.Yes)) 
            {
                Properties.Settings.Default.SaveRedeem = EnableRedeem.Text;
                Properties.Settings.Default.SaveCoins = totalChips.Text;
                Properties.Settings.Default.Save();
                Application.Exit(); //shows a message box to ask if user wants to exit and exits the program if yes
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            totalChips.Text = "1000";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            panelBuy.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panelBuy.Visible = false;
        }

        private void smallBuyChips_Click(object sender, EventArgs e)
        {
            int addChips = 0;
            var intChip = Convert.ToInt32(totalChips.Text);
            addChips = intChip + 1000;
            totalChips.Text = addChips.ToString();
        }

        private void mediumBuyChips_Click(object sender, EventArgs e)
        {
            int addChips = 0;
            int chipss = 10000;
            var intChip = Convert.ToInt32(totalChips.Text);
            addChips = intChip + chipss;
            totalChips.Text = addChips.ToString();
        }

        private void largeBuyChips_Click(object sender, EventArgs e)
        {
            int addChips = 0;
            var intChip = Convert.ToInt32(totalChips.Text);
            addChips = intChip + 100000;
            totalChips.Text = addChips.ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;

            timerlbl.Text = dt.ToLongTimeString();

            int one = 6; //times of day
            int two = 12;
            int three = 18;

            if (dt.Hour >= one && dt.Hour <= two)
            {
                EnableRedeem.Text = "1";
            }
            else if (dt.Hour > two && dt.Hour < three)
            {
                EnableRedeem.Text = "1";
            }
            else
            {
                EnableRedeem.Text = "1";
            }

        }
        private void FreeReward_Click(object sender, EventArgs e)
        {
            FreeReward.Visible = false;
            EnableRedeem.Text = "0";
            
            int addChips = 0;
            var intChip = Convert.ToInt32(totalChips.Text);
            addChips = intChip + 1000;
            totalChips.Text = addChips.ToString();

            Properties.Settings.Default.SaveRedeem = EnableRedeem.Text;
            Properties.Settings.Default.Save();
        }

        private void closeInfo_Click(object sender, EventArgs e)
        {
            panelInfo.Visible = false;
        }

        private void begingame_Click(object sender, EventArgs e)
        {
            totalChips.Text = "0";
            Properties.Settings.Default.SaveCoins = totalChips.Text;
            Properties.Settings.Default.Save();
        }

        private void raiseEmbtn_Click(object sender, EventArgs e)
        {
            passingLabel = totalChips.Text;
            this.Hide(); //hides the start form
            RaiseEm raiseem = new RaiseEm(); //creates a new form
            raiseem.Show(); //shows the new form that is created
            Properties.Settings.Default.SaveRedeem = EnableRedeem.Text;
            Properties.Settings.Default.Save();
        }
    } 
}
